Gopher source
https://www.raspberrypi.com/news/pianoai/